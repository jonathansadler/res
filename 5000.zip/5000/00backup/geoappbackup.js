var cors = require('cors');
const express = require('express')
const bodyParser = require('body-parser')
var geoip = require('geoip-lite');

var nodemailer = require('nodemailer');

// var http = require('http');

// express server definition
const app = express()

app.enable('trust proxy')
app.use(bodyParser.json())

//app.use(cors());
/*
app.use(cors({
  origin: 'http://yourapp.com'
  //http://truchart.co
}));
*/


/*
app.use(cors({
  origin: 'http://localhost:8000'
}));

*/

// Routes definitions
app.get('/', cors(), (req, res) => res.send(''))

app.get('/mail', cors(), async (req, res) => {
	
	var nemail = 'sadler.jonathan@gmail.com'
	var nsubject = 'test4'
	var nmessage = 'test4'
	
		/*
		
		,
		tls: {
			// do not fail on invalid certs
			rejectUnauthorized: false
		},
		
		*/
	
	     /*
		host: 'smtp.truchart.co',
        port: 587,
        secure: false, // true for 465, false for other ports
        */
	    // create reusable transporter object using the default SMTP transport
		
		/*
		port: 25,
		secure : false,
		v
		*/

	var transporter = nodemailer.createTransport({
		host: '0.0.0.0',
		port: 465,
		secure : true, // true for 465, false for other ports
		auth: {
			user: 'info@truchart.co',
			pass: 'Bara5@6'
		},
		tls: {
			// do not fail on invalid certs
			rejectUnauthorized: false
		},
	});

	
	
	
	var mailOptions = {
        from: '"Tru Chart" <info@truchart.co>', // sender address
        to: nemail, // list of receivers
        subject: nsubject, 
        text: nmessage
    }
	
	//html: 
	
	transporter.sendMail(mailOptions, function(error, info){
	  if (error) {
		res.send(error);
	  } else {
		res.send('Email sent: ' + info.response);
	  }
	});
	
	//res.send('done3')

})
	
	
	
app.get('/micros/api/ipinfo', cors(), async (req, res) => {

res.setHeader('Content-Type', 'application/json');	

//res.setHeader('Access-Control-Allow-Origin: *');
	
var ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
var geo = geoip.lookup(ip);		
	
	var jsonObject = {
        "ip": ip,
		"lat": geo.ll[0],
		"lng": geo.ll[1],
		"country":geo.country,
		"Region":geo.region,
		"city":geo.city,
		
    };
	
    res.send(jsonObject);
	//res.json(jsonObject);
})


// Running the server
const run = async () => {
  await app.listen(80, () => console.log(`Example app listening on port 3000!`))
}

run()
